<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>

<?php
$fn->error();
$fn->alert();
?>
</script>

</body>

</html>