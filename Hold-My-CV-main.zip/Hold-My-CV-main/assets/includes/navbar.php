<nav class="navbar bg-body-tertiary shadow">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="./assets/images/logoo.png" alt="Logo" height="50" class="d-inline-block align-text-top">
            </a>
            <div>
                <!-- <button class="btn btn-sm btn-dark"><i class="bi bi-person-circle"></i>Your Profile</button> -->
                <a href="actions/logout.action.php" class="btn btn-xl btn-danger"><i  class="bi bi-box-arrow-left p-1"></i>Logout</a>
            </div>
        </div>
    </nav>
